package android.jentabor.portfolionotes.persistence;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;
import android.jentabor.portfolionotes.models.JobNotes;

@Database(entities = {JobNotes.class}, version = 1) //version changes if program is updated at all
public abstract class JobNoteDatabase extends RoomDatabase {

    public static final String DATABASE_NAME = "jobNotes_db";

    private static JobNoteDatabase instance;

    static JobNoteDatabase getInstance(final Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(
                    context.getApplicationContext(),
                    JobNoteDatabase.class,
                    DATABASE_NAME
            ).build();
        }
        return instance;
    }

    public abstract NoteDao getNoteDao();
}


