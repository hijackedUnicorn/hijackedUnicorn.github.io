package android.jentabor.portfolionotes.models;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;


import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;

@Entity(tableName = "jobNotes")
public class JobNotes implements Parcelable {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "title")
    private String title;

    @ColumnInfo(name = "companyName")
    private String companyName;

    @ColumnInfo(name = "contactName")
    private String contactName;

    @ColumnInfo(name = "contactEmail")
    private String contactEmail;

    @ColumnInfo(name = "timestamp")
    private String timestamp;

    public JobNotes(String title, String companyName, String contactName, String contactEmail, String timestamp) {
        this.title = title;
        this.companyName = companyName;
        this.contactName = contactName;//content for now
        this.contactEmail = contactEmail; // part of the content for now
        this.timestamp = timestamp;
    }

    @Ignore
    public JobNotes() {

    }


    protected JobNotes(Parcel in) {
        id = in.readInt();
        title = in.readString();
        companyName = in.readString();
        contactName = in.readString();
        contactEmail = in.readString();
        timestamp = in.readString();
    }

    public static final Creator<JobNotes> CREATOR = new Creator<JobNotes>() {
        @Override
        public JobNotes createFromParcel(Parcel in) {
            return new JobNotes(in);
        }

        @Override
        public JobNotes[] newArray(int size) {
            return new JobNotes[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "JobNotes{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", companyName='" + companyName + '\'' +
                ", contactName='" + contactName + '\'' +
                ", contactEmail='" + contactEmail + '\'' +
                ", timestamp='" + timestamp + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(title);
        dest.writeString(companyName);
        dest.writeString(contactName);
        dest.writeString(contactEmail);
        dest.writeString(timestamp);
    }
}
