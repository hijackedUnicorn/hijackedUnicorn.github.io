package android.jentabor.portfolionotes.persistence;

import android.arch.lifecycle.LiveData;
import android.content.Context;
import android.jentabor.portfolionotes.async.DeleteAsyncTask;
import android.jentabor.portfolionotes.async.InsertAsyncTask;
import android.jentabor.portfolionotes.async.UpdateAsyncTask;
import android.jentabor.portfolionotes.models.JobNotes;

import java.util.List;

public class JobNoteRepository {

    private JobNoteDatabase mJobNoteDatabase;

    public JobNoteRepository(Context context) {
        mJobNoteDatabase = JobNoteDatabase.getInstance(context);
    }

    public void insertNoteTask(JobNotes jobNotes){
        new InsertAsyncTask(mJobNoteDatabase.getNoteDao()).execute(jobNotes);
    }

    public void updateNote(JobNotes jobNotes){
        new UpdateAsyncTask(mJobNoteDatabase.getNoteDao()).execute(jobNotes);
    }

    public LiveData<List<JobNotes>> retrieveNotesTask(){
        return mJobNoteDatabase.getNoteDao().getJobNotes();
    }

    public void deleteNote(JobNotes jobNotes){
        new DeleteAsyncTask(mJobNoteDatabase.getNoteDao()).execute(jobNotes);

    }

}
