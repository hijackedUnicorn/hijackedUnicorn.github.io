package android.jentabor.portfolionotes.async;

import android.jentabor.portfolionotes.models.JobNotes;
import android.jentabor.portfolionotes.persistence.NoteDao;
import android.os.AsyncTask;
import android.util.Log;

public class DeleteAsyncTask extends AsyncTask<JobNotes, Void, Void> {
    //async tasks are good for executing a single task then be destroyed once it is done
    private static final String TAG = "DeleteAsyncTask";
    private NoteDao mNoteDao;;

    public DeleteAsyncTask(NoteDao dao) {
        mNoteDao = dao;
    }

    @Override
    protected Void doInBackground(JobNotes... jobNotes) {
        Log.d(TAG, "doInBackground: thread: " + Thread.currentThread().getName()); //background thread is run different from the main threads
        mNoteDao.delete(jobNotes);
        return null;
    }
}