package android.jentabor.portfolionotes.persistence;

public class Jobs {
    // instance variables
    private int job_id;
    private String contactEmail;
    private String contactName;
    private String contactNumber;
    private String contactAddress;


    // empty constructor
    public Jobs() {}

    // constructor with all three variables
    public Jobs(int id, String email, String contact, String contactNumber, String contactAddress){
        this.job_id = id;
        this.contactEmail = email;
        this.contactName = contact;
        this.contactNumber = contactNumber;
        this.contactAddress = contactAddress;
    }

    // constructor without id
    public Jobs(String email, String contact, String contactNumber, String contactAddress){
        this.contactEmail = email;
        this.contactName = contact;
        this.contactAddress = contactAddress;
        this.contactNumber = contactNumber;
    }
    // setters (mutators)
    public void setID(int id) {this.job_id = id; }

    public void setContactEmail(String email) {this.contactEmail = email;}

    public void setContactName(String contact) {this.contactName = contact;}

    public void setContactNumber(String contactNumber) {this.contactNumber = contactNumber;}

    public void setContactAddress(String contactAddress){this.contactAddress = contactAddress;}

    // getters (accessors)
    public int getID() { return this.job_id; }

    public String getContactEmail() { return this.contactEmail; }

    public String getContactName() { return this.contactName; }

    public String getContactNumber() {return this.contactNumber; }

    public String getContactAddress() {return this.contactAddress;}
}

