package android.jentabor.portfolionotes;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.jentabor.portfolionotes.models.JobNotes;
import android.jentabor.portfolionotes.persistence.JobNoteRepository;
import android.jentabor.portfolionotes.util.Utility;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;

public class NoteActivity extends AppCompatActivity implements
        View.OnTouchListener,
        GestureDetector.OnGestureListener,
        GestureDetector.OnDoubleTapListener,
        View.OnClickListener,
        TextWatcher

{
    // Database components
    EditText ed1; // Refers to contact name
    EditText ed2; // Refers to phone number
    EditText ed3; // Refers to email address
    EditText ed4; // Refers to address
    Button mSave; // Save the data for contact information in note


    // Variables for shared preferences
    public static final String myPreferences = "myPrefs";
    public static final String contactName = "nameKey";
    public static final String contactEmail = "emailKey";
    public static final String contactPhone = "phoneKey";
    public static final String contactAddress = "addressKey";

    // Shared preference object
    SharedPreferences sharedPreferences;

    private static final String TAG = "NoteActivity";
    private static final int EDIT_MODE_ENABLED = 1;
    private static final int EDIT_MODE_DISABLED = 0;

    // ui components
    private LinedEditText mLinedEditText;
    private EditText mEditTitle;
    private TextView mViewTitle;
    //private EditText mEditContact;
    private RelativeLayout mCheckContainer, mBackArrowContainer;
    private ImageButton mCheck, mBackArrow;
    private EditText mEditPhone;
    private EditText mEditAddress;

    // vars
    private boolean mIsNewNote;
    private JobNotes mInitialNote;
    private GestureDetector mGestureDetector;
    private int mMode;
    private JobNoteRepository mJobNoteRepository;
    private JobNotes mFinalNote;

    private static final int ERROR_DIALOG_REQUEST = 9001;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
        mLinedEditText = findViewById(R.id.note_text);

        mEditTitle = findViewById(R.id.note_edit_title);
        mViewTitle = findViewById(R.id.note_text_title);
        mCheck = findViewById(R.id.toolbar_check);
        mBackArrow = findViewById(R.id.toolbar_back_arrow);
        mCheckContainer = findViewById(R.id.check_container);
        mBackArrowContainer = findViewById(R.id.back_arrow_container);

        mJobNoteRepository = new JobNoteRepository(this);

        ed1 = (findViewById(R.id.note_contact_name));
        ed2 = (findViewById(R.id.note_phone_number));
        ed3 = (findViewById(R.id.note_contact_email));
        ed4 = (findViewById(R.id.note_address));
        mSave = findViewById(R.id.save_contact); // Save button
        sharedPreferences = getSharedPreferences(myPreferences, Context.MODE_PRIVATE);

        isServicesOK();
        init();
        setListeners();

        if(getIncomingIntent()){
            //this is a new note, (EDIT MODE)
            setNewNoteProperties();
            enableEditMode();
            mSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String a = ed1.getText().toString();
                    String b = ed2.getText().toString();
                    String c = ed3.getText().toString();
                    String d = ed4.getText().toString();

                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString(contactName, a);
                    editor.putString(contactPhone, b);
                    editor.putString(contactEmail, c);
                    editor.putString(contactAddress, d);
                    editor.commit(); // Writes to storage immediately

                    Toast.makeText(NoteActivity.this, "Successfully Saved!", Toast.LENGTH_LONG).show();
                }
            });


        }
        else{
            //this is NOT a new note (VIEW MODE)
            setNoteProperties();
            disableContentInteraction();
        }

    }

    public void saveContact(View v){
        String a = ed1.getText().toString();
        String b = ed2.getText().toString();
        String c = ed3.getText().toString();
        String d = ed4.getText().toString();

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(contactName, a);
        editor.putString(contactPhone, b);
        editor.putString(contactEmail, c);
        editor.putString(contactAddress, d);
        editor.commit(); // Writes to storage immediately

        Toast.makeText(NoteActivity.this, "Successfully Saved!", Toast.LENGTH_LONG).show();

    }

    public void getContact(View v){
        sharedPreferences = getSharedPreferences(myPreferences, MODE_PRIVATE);
        if(sharedPreferences.contains(contactName)){
            ed1.setText(sharedPreferences.getString(contactName, ""));
        }
        if(sharedPreferences.contains(contactEmail)){
            ed3.setText(sharedPreferences.getString(contactEmail, ""));
        }
        if(sharedPreferences.contains(contactPhone)){
            ed2.setText(sharedPreferences.getString(contactPhone, ""));
        }
        if(sharedPreferences.contains(contactAddress)){
            ed4.setText(sharedPreferences.getString(contactAddress, ""));
        }
        Toast.makeText(NoteActivity.this, "Success! Retrived Contact", Toast.LENGTH_LONG).show();
    }
    private void setListeners(){
        mLinedEditText.setOnTouchListener(this);
        mGestureDetector = new GestureDetector(this, this);
        mViewTitle.setOnClickListener(this);
        mCheck.setOnClickListener(this);
        mBackArrow.setOnClickListener(this);
        mEditTitle.addTextChangedListener(this);

    }

    private boolean getIncomingIntent() {
        if(getIntent().hasExtra("selected_note")){
            mInitialNote = getIntent().getParcelableExtra("selected_note");

            mFinalNote = new JobNotes();
            mFinalNote.setTitle(mInitialNote.getTitle());
            mFinalNote.setContactName(mInitialNote.getContactName());
            mFinalNote.setTimestamp(mInitialNote.getTimestamp());
            mFinalNote.setId(mInitialNote.getId());

            mMode = EDIT_MODE_ENABLED;
            mIsNewNote = false;
            return false;
        }
        mMode = EDIT_MODE_ENABLED;
        mIsNewNote = true;
        return true;
    }

    private void saveChanges(){
        if(mIsNewNote){
            saveNewNote();
        }
        else{
            updateNote();
        }
    }

    private void updateNote(){
        mJobNoteRepository.updateNote(mFinalNote);

    }

    private void saveNewNote() {
        mJobNoteRepository.insertNoteTask(mFinalNote);
    }

    private void disableContentInteraction(){
        mLinedEditText.setKeyListener(null);
        mLinedEditText.setFocusable(false);
        mLinedEditText.setFocusableInTouchMode(false);
        mLinedEditText.setCursorVisible(false);
        mLinedEditText.clearFocus();
    }

    private void enableContentInteraction(){
        mLinedEditText.setKeyListener(new EditText(this).getKeyListener());
        mLinedEditText.setFocusable(true);
        mLinedEditText.setFocusableInTouchMode(true);
        mLinedEditText.setCursorVisible(true);
        mLinedEditText.requestFocus();

    }

    private void enableEditMode(){
        mBackArrowContainer.setVisibility(View.GONE);
        mCheckContainer.setVisibility(View.VISIBLE);

        mViewTitle.setVisibility(View.GONE);
        mEditTitle.setVisibility(View.VISIBLE);

        mMode = EDIT_MODE_ENABLED;

        enableContentInteraction();
    }

    private void disableEditMode(){
        Log.d(TAG, "disableEditMode: called");
        mBackArrowContainer.setVisibility(View.VISIBLE);
        mCheckContainer.setVisibility(View.GONE);

        mViewTitle.setVisibility(View.VISIBLE);
        mEditTitle.setVisibility(View.GONE);

        mMode = EDIT_MODE_DISABLED;

        disableContentInteraction();

        // Check if they typed anything into the note. Don't want to save an empty note.
        String temp = mLinedEditText.getText().toString();
        temp = temp.replace("\n", "");
        temp = temp.replace(" ", "");
        if(temp.length() > 0) {
            mFinalNote.setTitle(mEditTitle.getText().toString());
            mFinalNote.setContactName(mLinedEditText.getText().toString()); //content for now
            String timestamp = Utility.getCurrentTimestamp();
            mFinalNote.setTimestamp(timestamp);

            Log.d(TAG, "disableEditMode: initial: " + mInitialNote.toString());
            Log.d(TAG, "disableEditMode: final: " + mFinalNote.toString());

            // If the note was altered, save it.
            if (!mFinalNote.getContactName().equals(mInitialNote.getContactName())
                    || !mFinalNote.getTitle().equals(mInitialNote.getTitle())) {
                Log.d(TAG, "disableEditMode: called?");
                saveChanges();
            }
        }
    }


    private void setNoteProperties(){
        mViewTitle.setText(mInitialNote.getTitle());
        mEditTitle.setText(mInitialNote.getTitle());
        mLinedEditText.setText(mInitialNote.getContactName());

    }

    private void setNewNoteProperties(){
        mViewTitle.setText("");//android:hint<> will show company name prompt
        mEditTitle.setText("");

        mInitialNote = new JobNotes();
        mFinalNote = new JobNotes();
        mInitialNote.setTitle("");


    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {

        return mGestureDetector.onTouchEvent(event);
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        Log.d(TAG, "onDoubleTap:  double tapped!");
        enableEditMode();;
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return false;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.toolbar_check:{
                disableEditMode();
                break;
            }
            case R.id.note_text_title: {
                enableEditMode();
                mEditTitle.requestFocus();
                mEditTitle.setSelection(mEditTitle.length());
                break;
            }

            case R.id.toolbar_back_arrow: {
                finish();
                break;
            }
        }
    }

    @Override
    public void onBackPressed() {
        if(mMode==EDIT_MODE_ENABLED){
            onClick(mCheck);
        }
        else {
            super.onBackPressed();
        }

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("mode", mMode);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        mMode = savedInstanceState.getInt("mode");
        if(mMode == EDIT_MODE_ENABLED){
            enableEditMode();
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        mViewTitle.setText(s.toString());

    }

    @Override
    public void afterTextChanged(Editable s) {

    }
    /* CodingWithMitch. (2017, October 4). Google maps API setup (part 2).
     * [Video file]. Retrieved from https://www.youtube.com/watch?v=M0bYvXlhgSI
     */


    private void init(){
        Button btnMap = findViewById(R.id.map);
        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NoteActivity.this, MapsActivity.class);
                startActivity(intent);
            }
        });
    }
    public boolean isServicesOK() {
        Log.d(TAG, "isServicesOK: checking google services version");
        int available = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(NoteActivity.this);
        if (available == ConnectionResult.SUCCESS){
            // everything is fine and the user can make map requests
            Log.d(TAG, "isServicesOK: Google Play Services is working");
            return true;
        }
        else if(GoogleApiAvailability.getInstance().isUserResolvableError(available)){
            // an error occurred but we can resolve it
            Log.d(TAG, "isServicesOK: an error occurred but we can fix it");
            Dialog dialog = GoogleApiAvailability.getInstance().getErrorDialog(NoteActivity.this, available, ERROR_DIALOG_REQUEST);
            dialog.show();
        }else{
            Toast.makeText(this, "You can't make map requests", Toast.LENGTH_SHORT).show();
        }
        return false;
    }
}