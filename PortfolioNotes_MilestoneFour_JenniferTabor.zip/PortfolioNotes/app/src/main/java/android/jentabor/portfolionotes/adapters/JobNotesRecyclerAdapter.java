package android.jentabor.portfolionotes.adapters;

import android.jentabor.portfolionotes.R;
import android.jentabor.portfolionotes.models.JobNotes;
import android.jentabor.portfolionotes.util.Utility;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.support.annotation.NonNull;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class JobNotesRecyclerAdapter extends RecyclerView.Adapter<JobNotesRecyclerAdapter.ViewHolder> {

    private static final String TAG = "JobNotesRecyclerAdapter";
    
    private ArrayList<JobNotes> mJobNotes = new ArrayList<>();
    private OnNoteListener mOnNoteListener;

    public JobNotesRecyclerAdapter(ArrayList<JobNotes> mJobNotes, OnNoteListener onNoteListener) {
        this.mJobNotes = mJobNotes;
        this.mOnNoteListener = onNoteListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.layout_note_list_item, viewGroup, false );
        return new ViewHolder(view, mOnNoteListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

        try{
            String month = mJobNotes.get(i).getTimestamp().substring(0, 2);
            month = Utility.getMonthFromNumber(month);
            String year = mJobNotes.get(i).getTimestamp().substring(3);
            String timestamp = month + " " + year;
            viewHolder.timestamp.setText(timestamp);
            viewHolder.title.setText(mJobNotes.get(i).getTitle());
        }catch (NullPointerException e){
            Log.e(TAG, "onBindViewHolder: NullPointerException: " + e.getMessage());
        }
    }

    @Override
    public int getItemCount() {
        return mJobNotes.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView title, timestamp;
        OnNoteListener onNoteListener;

        public ViewHolder(@NonNull View itemView, OnNoteListener onNoteListener){
            super(itemView);
            title = itemView.findViewById(R.id.job_title);
            timestamp = itemView.findViewById(R.id.note_timestamp);
            this.onNoteListener = onNoteListener;

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            onNoteListener.onNoteClick(getAdapterPosition());
        }
    }
    public interface OnNoteListener{
        void onNoteClick(int position);
    }
}
