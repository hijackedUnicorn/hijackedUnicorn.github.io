package android.jentabor.portfolionotes.persistence;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;
import android.jentabor.portfolionotes.models.JobNotes;

import java.util.List;

//Data Access Object : contains methods to access database
@Dao
public interface NoteDao {

    @Insert
    long[] insertNotes(JobNotes... jobNotes);


    @Query("SELECT * FROM jobNotes")
    LiveData<List<JobNotes>> getJobNotes(); // LiveData is a data observation class

    @Query("SELECT * FROM jobNotes WHERE title LIKE :title")
    List<JobNotes> getNoteWithCustomQuery(String title);

    @Delete
    int delete(JobNotes... jobNotes);

    @Update
    int update(JobNotes... jobNotes);

}
