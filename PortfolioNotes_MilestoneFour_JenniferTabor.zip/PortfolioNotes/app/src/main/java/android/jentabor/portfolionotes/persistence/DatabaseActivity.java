package android.jentabor.portfolionotes.persistence;

import android.jentabor.portfolionotes.R;
import android.jentabor.portfolionotes.models.JobsDBHandler;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class DatabaseActivity extends AppCompatActivity {
    TextView idView;    // this object refers to the auto assigned JobID
    TextView contactPhoneBox; //this object is referring to the company name EditText
    TextView contactNameBox; // this object is referring to the contact name EditText
    EditText contactEmailBox;
    EditText contactAddressBox;



    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);

        idView = (TextView) findViewById(R.id.jobID);
        contactPhoneBox = (EditText) findViewById(R.id.note_phone_number); // this points to the phone number field
        contactNameBox = (EditText) findViewById(R.id.note_contact_name); // this points to the contact name field
        contactEmailBox = (EditText) findViewById(R.id.note_contact_email); // this points to the contact email field
        contactAddressBox = (EditText) findViewById(R.id.note_address); // this points to the contact address field
    }
    // This is the method created to add new jobs to the database when the user clicks add
    // which is called in the activity_main.xml file
    public void addJob(View view) {
        JobsDBHandler dbHandler = new JobsDBHandler(this, null, null, 1 );
        String contactNumber = contactPhoneBox.getText().toString();
        String contact = contactNameBox.getText().toString();
        String email = contactEmailBox.getText().toString();
        String contactAddress = contactAddressBox.getText().toString();

        Jobs jobs = new Jobs(contact, email, contactNumber, contactAddress );

        dbHandler.addJob(jobs);

        contactPhoneBox.setText("");
        contactNameBox.setText("");
        contactEmailBox.setText("");
        contactAddressBox.setText("");
    }

    // This method is created to when the user clicks to search for a company in
    // the database. It is called in the activity_main.xml file
    public void searchJobs(View view){
        JobsDBHandler dbHandler = new JobsDBHandler(this, null, null, 1);
        Jobs job = dbHandler.searchJobs(contactPhoneBox.getText().toString());

        if (job != null) {
            idView.setText(String.valueOf(job.getID()));
            contactPhoneBox.setText(String.valueOf(job.getContactEmail()));
            contactNameBox.setText(String.valueOf(job.getContactName()));
        }
        else {
            idView.setText("Contact not found");
        }
    }

    // This is method for deleting a job and it too is called in the activity_main.xml file
    public void deleteJob(View view) {
        JobsDBHandler dbHandler= new JobsDBHandler(this, null, null, 1);
        boolean result = dbHandler.deleteJob(contactPhoneBox.getText().toString());

        if (result)
        {
            idView.setText("Company Deleted");
            contactPhoneBox.setText("");
            contactNameBox.setText("");
        }
        else
            idView.setText("Company not found.");

    }
}
