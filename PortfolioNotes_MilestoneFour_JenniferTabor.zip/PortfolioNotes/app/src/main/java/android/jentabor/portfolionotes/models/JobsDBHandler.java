package android.jentabor.portfolionotes.models;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.jentabor.portfolionotes.persistence.Jobs;

public class JobsDBHandler extends SQLiteOpenHelper {
    // database name and version
    private static final int DB_VER = 1;
    private static final String DB_NAME = "jobsDB.db";

    // table
    public static final String TABLE_JOBS = "jobs";

    // columns
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_COMPANY_NUMBER = "phone";
    public static final String COLUMN_CONTACT_NAME = "contact";
    public static final String COLUMN_CONTACT_EMAIL = "email";
    public static final String COLUMN_COMPANY_ADDRESS = "address";
    private String contactName;

    // constructor
    public JobsDBHandler(Context context, String name,
                         SQLiteDatabase.CursorFactory factory, int version){
        super(context, DB_NAME, factory, DB_VER);
    }

    // This method creates the Jobs table when the DB is initialized.
    // It contains all the edit text fields from the activity_note.xml layout
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_JOBS_TABLE = "CREATE TABLE " +
                TABLE_JOBS + "(" +
                COLUMN_ID + "INTEGER PRIMARY KEY," +
                COLUMN_CONTACT_NAME + "TEXT" +
                COLUMN_COMPANY_NUMBER + "TEXT" +
                COLUMN_CONTACT_EMAIL + "TEXT" +
                COLUMN_COMPANY_ADDRESS + "TEXT" + ")";

        db.execSQL(CREATE_JOBS_TABLE);
    }

    // This method closes an open DB if a new one is created.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_JOBS);
        onCreate(db);
    }

    // This method is used to add a Job record to the database
    public void addJob(Jobs job){
        ContentValues values = new ContentValues();
        values.put(COLUMN_CONTACT_NAME, job.getContactName());
        values.put(COLUMN_COMPANY_NUMBER, job.getContactNumber());
        values.put(COLUMN_CONTACT_EMAIL, job.getContactEmail());
        values.put(COLUMN_COMPANY_ADDRESS, job.getContactAddress());


        SQLiteDatabase db = this.getWritableDatabase();

        db.insert(TABLE_JOBS, null, values);
        db.close();
    }
    // implements the search/find functionality
    public Jobs searchJobs(String contactName) {
        String query = "SELECT * FROM " +
                TABLE_JOBS + "WHERE" + COLUMN_CONTACT_NAME +
                " = \"" + contactName + "\"";

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        Jobs job = new Jobs();

        if (cursor.moveToFirst()){
            cursor.moveToFirst();
            job.setID(Integer.parseInt(cursor.getString(0)));
            job.setContactEmail(cursor.getString(3));
            job.setContactName((cursor.getString(1)));
            job.setContactAddress((cursor.getString(4)));
            job.setContactNumber((cursor.getString(2)));
            cursor.close();
        }
        else {
            job = null;
        }
        db.close();
        return job;
    }

    // implements the delete job functionality
    public boolean deleteJob(String contactName) {
        this.contactName = contactName;
        boolean result = false;
        String query = "SELECT * FROM " + TABLE_JOBS +
                "WHERE" + COLUMN_CONTACT_NAME + "= \"" + contactName + "\"";
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        Jobs job = new Jobs();

        if (cursor.moveToFirst()) {
            job.setID(Integer.parseInt(cursor.getString(0)));
            db.delete(TABLE_JOBS, COLUMN_ID + " = ?",
                    new String[] { String.valueOf(job.getID())
                    });
        }
        db.close();
        return result;
    }
}
